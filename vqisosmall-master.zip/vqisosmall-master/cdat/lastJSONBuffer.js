{
	"untypedList_root_0": {
		"gradientList_Gradients_0": {
			"gradientStepList_NullGrad_0": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 1,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 1,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Gold_1": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.8,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.125,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.5,
					"number_Lightness_2": 0.2,
					"number_Power_3": 0.5,
					"number_Position_4": 0.0784313725490196
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.3,
					"number_Lightness_2": 0.1,
					"number_Power_3": 0.125,
					"number_Position_4": 0.10980392156862745
				},
				"gradientStep_Step3_3": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.2,
					"number_Lightness_2": 0.2,
					"number_Power_3": 0.125,
					"number_Position_4": 0.1568627450980392
				},
				"gradientStep_Step4_4": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.8,
					"number_Lightness_2": 0.8,
					"number_Power_3": 0.5,
					"number_Position_4": 0.47058823529411764
				},
				"gradientStep_Step5_5": {
					"number_Hue_0": 0.8,
					"number_Saturation_1": 0.5,
					"number_Lightness_2": 0.4,
					"number_Power_3": 0.125,
					"number_Position_4": 0.5019607843137255
				},
				"gradientStep_Step6_6": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.8,
					"number_Lightness_2": 0.9,
					"number_Power_3": 0.125,
					"number_Position_4": 0.7529411764705882
				},
				"gradientStep_Step7_7": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.1,
					"number_Lightness_2": 1,
					"number_Power_3": 0.5,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Purple_2": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.4,
					"number_Lightness_2": 0,
					"number_Power_3": 0.125,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.2,
					"number_Lightness_2": 0.5,
					"number_Power_3": 0.075,
					"number_Position_4": 0.7529411764705882
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.1,
					"number_Lightness_2": 1,
					"number_Power_3": 0.025,
					"number_Position_4": 1
				}
			},
			"gradientStepList_SkyBlue_3": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.1,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.5,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.4,
					"number_Saturation_1": 0.8,
					"number_Lightness_2": 1,
					"number_Power_3": 0.125,
					"number_Position_4": 0.5019607843137255
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.4,
					"number_Saturation_1": 0.1,
					"number_Lightness_2": 1,
					"number_Power_3": 0.5,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Silver_4": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.125,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.1,
					"number_Lightness_2": 0.2,
					"number_Power_3": 0.5,
					"number_Position_4": 0.0784313725490196
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0.1,
					"number_Power_3": 0.125,
					"number_Position_4": 0.10980392156862745
				},
				"gradientStep_Step3_3": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0.2,
					"number_Power_3": 0.125,
					"number_Position_4": 0.1568627450980392
				},
				"gradientStep_Step4_4": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.2,
					"number_Lightness_2": 0.8,
					"number_Power_3": 0.5,
					"number_Position_4": 0.47058823529411764
				},
				"gradientStep_Step5_5": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.1,
					"number_Lightness_2": 0.4,
					"number_Power_3": 0.125,
					"number_Position_4": 0.5019607843137255
				},
				"gradientStep_Step6_6": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.2,
					"number_Lightness_2": 0.9,
					"number_Power_3": 0.125,
					"number_Position_4": 0.7529411764705882
				},
				"gradientStep_Step7_7": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0.2,
					"number_Lightness_2": 1,
					"number_Power_3": 0.5,
					"number_Position_4": 1
				}
			},
			"gradientStepList_HeightMap_5": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.5806451612903226,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.796844181459566,
					"number_Power_3": 0.27350427350427353,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.6451612903225806,
					"number_Saturation_1": 0.1893491124260355,
					"number_Lightness_2": 0.20775805391190005,
					"number_Power_3": 0.2603550295857988,
					"number_Position_4": 0.1393819855358317
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.8709677419354839,
					"number_Lightness_2": 0.06451612903225806,
					"number_Power_3": 0.2787639710716634,
					"number_Position_4": 0.07100591715976332
				},
				"gradientStep_Step3_3": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.6451612903225806,
					"number_Power_3": 0.3129520052596976,
					"number_Position_4": 0.6916502301117686
				},
				"gradientStep_Step4_4": {
					"number_Hue_0": 0.25806451612903225,
					"number_Saturation_1": 0.12903225806451613,
					"number_Lightness_2": 0.6129032258064516,
					"number_Power_3": 0.63379355687048,
					"number_Position_4": 0.4339250493096647
				},
				"gradientStep_Step5_5": {
					"number_Hue_0": 0.2903225806451613,
					"number_Saturation_1": 0,
					"number_Lightness_2": 1,
					"number_Power_3": 0.0762656147271532,
					"number_Position_4": 1
				}
			},
			"gradientStepList_SeaMap_6": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.06451612903225806,
					"number_Saturation_1": 0.36554898093359633,
					"number_Lightness_2": 0.16305062458908612,
					"number_Power_3": 0.26298487836949375,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.22580645161290322,
					"number_Saturation_1": 0.42077580539119,
					"number_Lightness_2": 0.8494411571334648,
					"number_Power_3": 0.294543063773833,
					"number_Position_4": 1
				}
			},
			"gradientStepList_BlueGray_7": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.2375085557837098,
					"number_Saturation_1": 0.043121149897330596,
					"number_Lightness_2": 0.06776180698151951,
					"number_Power_3": 0.23477070499657768,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.4,
					"number_Saturation_1": 0.1,
					"number_Lightness_2": 1,
					"number_Power_3": 0.075,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Dirt_8": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.22090729783037474,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.12903225806451613,
					"number_Power_3": 0.2182774490466798,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.11045364891518737,
					"number_Lightness_2": 0.3076923076923077,
					"number_Power_3": 0.2971729125575279,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Dirt2_9": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.3225806451612903,
					"number_Lightness_2": 0,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7741935483870968,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.06451612903225806,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7741935483870968,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.41935483870967744,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Stone_10": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.0967741935483871,
					"number_Lightness_2": 0.10782380013149244,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.5285996055226825,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.24194608809993426,
					"number_Lightness_2": 0.7021696252465484,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Stone2_11": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.14990138067061143,
					"number_Lightness_2": 0.27087442472057854,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.6916502301117686,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.06451612903225806,
					"number_Lightness_2": 0.9354838709677419,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Grass_12": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.3548387096774194,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.3870967741935484,
					"number_Saturation_1": 0.06451612903225806,
					"number_Lightness_2": 0.06451612903225806,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5470085470085471
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.12903225806451613,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Grass2_13": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.03225806451612903,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.45161290322580644,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.3870967741935484,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.715318869165023
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.4838709677419355,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.6774193548387096,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Sand_14": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.0967741935483871,
					"number_Lightness_2": 0.10782380013149244,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.5285996055226825,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.24194608809993426,
					"number_Lightness_2": 0.7021696252465484,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Sand2_15": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.14990138067061143,
					"number_Lightness_2": 0.27087442472057854,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.6916502301117686,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.06451612903225806,
					"number_Lightness_2": 0.9354838709677419,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Mortar_16": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.12903225806451613,
					"number_Saturation_1": 0.09204470742932282,
					"number_Lightness_2": 0.20775805391190005,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.06451612903225806,
					"number_Saturation_1": 0.03225806451612903,
					"number_Lightness_2": 0.4444444444444444,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.0967741935483871,
					"number_Saturation_1": 0.03225806451612903,
					"number_Lightness_2": 0.7547666009204471,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Mortar2_17": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.03225806451612903,
					"number_Saturation_1": 0.06451612903225806,
					"number_Lightness_2": 0.4812623274161736,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.22580645161290322,
					"number_Saturation_1": 0.03225806451612903,
					"number_Lightness_2": 0.6758711374095989,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.1935483870967742,
					"number_Saturation_1": 0.03225806451612903,
					"number_Lightness_2": 0.8547008547008547,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Wood_18": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7419354838709677,
					"number_Saturation_1": 0.18408941485864563,
					"number_Lightness_2": 0.057856673241288625,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7419354838709677,
					"number_Saturation_1": 0.14201183431952663,
					"number_Lightness_2": 0.126232741617357,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7419354838709677,
					"number_Saturation_1": 0.1814595660749507,
					"number_Lightness_2": 0.084155161078238,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Wood2_19": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7419354838709677,
					"number_Saturation_1": 0.11571334648257725,
					"number_Lightness_2": 0.023668639053254437,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7419354838709677,
					"number_Saturation_1": 0.1814595660749507,
					"number_Lightness_2": 0.0762656147271532,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7419354838709677,
					"number_Saturation_1": 0.1814595660749507,
					"number_Lightness_2": 0.18408941485864563,
					"number_Power_3": 0.14201183431952663,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Brick_20": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7310979618671927,
					"number_Saturation_1": 0.3497698882314267,
					"number_Lightness_2": 0.07363576594345825,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7731755424063116,
					"number_Saturation_1": 0.2445759368836292,
					"number_Lightness_2": 0.210387902695595,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8073635765943459,
					"number_Saturation_1": 0.39447731755424065,
					"number_Lightness_2": 0.378698224852071,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Brick2_21": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.673241288625904,
					"number_Saturation_1": 0.5338593030900723,
					"number_Lightness_2": 0.05259697567389875,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7416173570019724,
					"number_Saturation_1": 0.33925049309664695,
					"number_Lightness_2": 0.2235371466140697,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8389217619986851,
					"number_Saturation_1": 0.2892833662064431,
					"number_Lightness_2": 0.42077580539119,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Shingle_22": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.1935483870967742,
					"number_Saturation_1": 0.2656147271531887,
					"number_Lightness_2": 0.084155161078238,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.32873109796186717,
					"number_Saturation_1": 0.6890203813280736,
					"number_Lightness_2": 0.1946088099934254,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.2903225806451613,
					"number_Saturation_1": 0.2866535174227482,
					"number_Lightness_2": 0.8387096774193549,
					"number_Power_3": 0.6600920447074293,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Shingle2_23": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 1,
					"number_Saturation_1": 0.12903225806451613,
					"number_Lightness_2": 0,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 1,
					"number_Saturation_1": 0.5806451612903226,
					"number_Lightness_2": 0.1935483870967742,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 1,
					"number_Saturation_1": 0.25806451612903225,
					"number_Lightness_2": 0.7096774193548387,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Shingle3_24": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.19723865877712032,
					"number_Saturation_1": 0.2903225806451613,
					"number_Lightness_2": 0,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.19197896120973043,
					"number_Saturation_1": 0.5806451612903226,
					"number_Lightness_2": 0.22580645161290322,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5627876397107167
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.24983563445101906,
					"number_Saturation_1": 0.9354838709677419,
					"number_Lightness_2": 0.6774193548387096,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Shingle4_25": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.45161290322580644,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.0967741935483871,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.6451612903225806,
					"number_Lightness_2": 0.12903225806451613,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.4838709677419355,
					"number_Saturation_1": 0.2903225806451613,
					"number_Lightness_2": 0.7419354838709677,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Shingle5_26": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.6451612903225806,
					"number_Saturation_1": 0.25806451612903225,
					"number_Lightness_2": 0.06451612903225806,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.6451612903225806,
					"number_Saturation_1": 0.7741935483870968,
					"number_Lightness_2": 0.2903225806451613,
					"number_Power_3": 0.16568047337278108,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.6451612903225806,
					"number_Saturation_1": 0.8387096774193549,
					"number_Lightness_2": 0.967741935483871,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Shingle6_27": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.8064516129032258,
					"number_Saturation_1": 0.0967741935483871,
					"number_Lightness_2": 0.03225806451612903,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.8387096774193549,
					"number_Saturation_1": 0.5759368836291914,
					"number_Lightness_2": 0.16129032258064516,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8387096774193549,
					"number_Saturation_1": 0.336620644312952,
					"number_Lightness_2": 0.8387096774193549,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Plaster_28": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7495069033530573,
					"number_Saturation_1": 0.1893491124260355,
					"number_Lightness_2": 0.05259697567389875,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7258382642998028,
					"number_Saturation_1": 0.2314266929651545,
					"number_Lightness_2": 0.5338593030900723,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.31821170282708744
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.6101249178172256,
					"number_Saturation_1": 0.10256410256410256,
					"number_Lightness_2": 1,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Plaster2_29": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.3225806451612903,
					"number_Lightness_2": 0,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.8064516129032258,
					"number_Saturation_1": 0.3548387096774194,
					"number_Lightness_2": 0.0967741935483871,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8064516129032258,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.2903225806451613,
					"number_Power_3": 0.21301775147928995,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Debug_30": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				}
			},
			"gradientStepList_Debug2_31": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 1,
					"number_Power_3": 0.28402366863905326,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0,
					"number_Saturation_1": 0,
					"number_Lightness_2": 1,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5
				}
			},
			"gradientStepList_Water_32": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.1893491124260355,
					"number_Saturation_1": 0.5443786982248521,
					"number_Lightness_2": 0.05259697567389875,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.27613412228796846,
					"number_Saturation_1": 0.2787639710716634,
					"number_Lightness_2": 0.4444444444444444,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.5654174884944115
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.2971729125575279,
					"number_Saturation_1": 0.2577251808021039,
					"number_Lightness_2": 0.8099934253780408,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Metal_33": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.8,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.125,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.16042077580539119,
					"number_Lightness_2": 0.0495703899537343,
					"number_Power_3": 0.5,
					"number_Position_4": 0.0784313725490196
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.1393819855358317,
					"number_Lightness_2": 0.05750165234633179,
					"number_Power_3": 0.125,
					"number_Position_4": 0.10980392156862745
				},
				"gradientStep_Step3_3": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.11045364891518737,
					"number_Lightness_2": 0.06014540647719762,
					"number_Power_3": 0.125,
					"number_Position_4": 0.1568627450980392
				},
				"gradientStep_Step4_4": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.1525312294543064,
					"number_Lightness_2": 0.06278916060806344,
					"number_Power_3": 0.5,
					"number_Position_4": 0.47058823529411764
				},
				"gradientStep_Step5_5": {
					"number_Hue_0": 0.8,
					"number_Saturation_1": 0.14464168310322156,
					"number_Lightness_2": 0.08922670191672175,
					"number_Power_3": 0.125,
					"number_Position_4": 0.5019607843137255
				},
				"gradientStep_Step6_6": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.12886259040105194,
					"number_Lightness_2": 0.23727693324520818,
					"number_Power_3": 0.125,
					"number_Position_4": 0.7529411764705882
				},
				"gradientStep_Step7_7": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.0631163708086785,
					"number_Lightness_2": 0.6787838730998017,
					"number_Power_3": 0.5,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Metal2_34": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.8,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.125,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.1472715318869165,
					"number_Lightness_2": 0.0495703899537343,
					"number_Power_3": 0.5,
					"number_Position_4": 0.0784313725490196
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.1525312294543064,
					"number_Lightness_2": 0.05485789821546596,
					"number_Power_3": 0.125,
					"number_Position_4": 0.10980392156862745
				},
				"gradientStep_Step3_3": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.12360289283366206,
					"number_Lightness_2": 0.06543291473892927,
					"number_Power_3": 0.125,
					"number_Position_4": 0.1568627450980392
				},
				"gradientStep_Step4_4": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.0945142101784534,
					"number_Lightness_2": 0.05750165234633179,
					"number_Power_3": 0.5,
					"number_Position_4": 0.47058823529411764
				},
				"gradientStep_Step5_5": {
					"number_Hue_0": 0.8,
					"number_Saturation_1": 0.09187045604758758,
					"number_Lightness_2": 0.06278916060806344,
					"number_Power_3": 0.125,
					"number_Position_4": 0.5019607843137255
				},
				"gradientStep_Step6_6": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.1130204890945142,
					"number_Lightness_2": 0.20819563780568406,
					"number_Power_3": 0.125,
					"number_Position_4": 0.7529411764705882
				},
				"gradientStep_Step7_7": {
					"number_Hue_0": 0.75,
					"number_Saturation_1": 0.07889546351084813,
					"number_Lightness_2": 0.6867151354923992,
					"number_Power_3": 0.5,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Glass_35": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.22616699539776464,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.125,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.16568047337278108,
					"number_Saturation_1": 0.1553205551883675,
					"number_Lightness_2": 0.2,
					"number_Power_3": 0.5,
					"number_Position_4": 0.0784313725490196
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.1814595660749507,
					"number_Saturation_1": 0.13681427627230666,
					"number_Lightness_2": 0.1,
					"number_Power_3": 0.125,
					"number_Position_4": 0.10980392156862745
				},
				"gradientStep_Step3_3": {
					"number_Hue_0": 0.0762656147271532,
					"number_Saturation_1": 0.16060806345009915,
					"number_Lightness_2": 0.2,
					"number_Power_3": 0.125,
					"number_Position_4": 0.1568627450980392
				},
				"gradientStep_Step4_4": {
					"number_Hue_0": 0.22090729783037474,
					"number_Saturation_1": 0.2267019167217449,
					"number_Lightness_2": 0.8,
					"number_Power_3": 0.5,
					"number_Position_4": 0.47058823529411764
				},
				"gradientStep_Step5_5": {
					"number_Hue_0": 0.14464168310322156,
					"number_Saturation_1": 0.19233311302048908,
					"number_Lightness_2": 0.4,
					"number_Power_3": 0.125,
					"number_Position_4": 0.5019607843137255
				},
				"gradientStep_Step6_6": {
					"number_Hue_0": 0.1525312294543064,
					"number_Saturation_1": 0.18704560475875742,
					"number_Lightness_2": 0.9,
					"number_Power_3": 0.125,
					"number_Position_4": 0.7529411764705882
				},
				"gradientStep_Step7_7": {
					"number_Hue_0": 0.21564760026298488,
					"number_Saturation_1": 0.13681427627230666,
					"number_Lightness_2": 1,
					"number_Power_3": 0.5,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Earth_36": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.8178829717291256,
					"number_Saturation_1": 0.1893491124260355,
					"number_Lightness_2": 0,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.8021038790269559,
					"number_Saturation_1": 0.12360289283366206,
					"number_Lightness_2": 0.028928336620644313,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.31821170282708744
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8362919132149902,
					"number_Saturation_1": 0.10256410256410256,
					"number_Lightness_2": 0.042077580539119,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Earth2_37": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7495069033530573,
					"number_Saturation_1": 0.1893491124260355,
					"number_Lightness_2": 0.05259697567389875,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7915844838921762,
					"number_Saturation_1": 0.2603550295857988,
					"number_Lightness_2": 0.047337278106508875,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.31821170282708744
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8284023668639053,
					"number_Saturation_1": 0.24983563445101906,
					"number_Lightness_2": 0.084155161078238,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Earth3_38": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7495069033530573,
					"number_Saturation_1": 0.1893491124260355,
					"number_Lightness_2": 0.05259697567389875,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7915844838921762,
					"number_Saturation_1": 0.16305062458908612,
					"number_Lightness_2": 0.2024983563445102,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.31821170282708744
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8547008547008547,
					"number_Saturation_1": 0.1472715318869165,
					"number_Lightness_2": 0.5259697567389875,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Earth4_39": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7495069033530573,
					"number_Saturation_1": 0.2866535174227482,
					"number_Lightness_2": 0.1472715318869165,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7889546351084813,
					"number_Saturation_1": 0.29980276134122286,
					"number_Lightness_2": 0.32610124917817224,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.31821170282708744
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.757396449704142,
					"number_Saturation_1": 0.168310322156476,
					"number_Lightness_2": 0.4470742932281394,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Earth5_40": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7495069033530573,
					"number_Saturation_1": 0.2656147271531887,
					"number_Lightness_2": 0.05259697567389875,
					"number_Power_3": 0.210387902695595,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7258382642998028,
					"number_Saturation_1": 0.252465483234714,
					"number_Lightness_2": 0.1393819855358317,
					"number_Power_3": 0.22879684418145957,
					"number_Position_4": 0.31821170282708744
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.8468113083497699,
					"number_Saturation_1": 0.18671926364234057,
					"number_Lightness_2": 0.4181459566074951,
					"number_Power_3": 0.13675213675213677,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Bark_41": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.8003965631196299,
					"number_Saturation_1": 0.1130204890945142,
					"number_Lightness_2": 0.08393919365499009,
					"number_Power_3": 0.22090729783037474,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7528089887640449,
					"number_Saturation_1": 0.15267680105750164,
					"number_Lightness_2": 0.17647058823529413,
					"number_Power_3": 0.2182774490466798,
					"number_Position_4": 0.5
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7580964970257766,
					"number_Saturation_1": 0.17118307997356247,
					"number_Lightness_2": 0.38797091870456046,
					"number_Power_3": 0.2971729125575279,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Bark2_42": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.6787838730998017,
					"number_Saturation_1": 0.21877065432914738,
					"number_Lightness_2": 0.18704560475875742,
					"number_Power_3": 0.22090729783037474,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7607402511566425,
					"number_Saturation_1": 0.17911434236615995,
					"number_Lightness_2": 0.3192333113020489,
					"number_Power_3": 0.2182774490466798,
					"number_Position_4": 0.5571711830799736
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.6734963648380701,
					"number_Saturation_1": 0.19762062128222074,
					"number_Lightness_2": 0.8426966292134831,
					"number_Power_3": 0.2971729125575279,
					"number_Position_4": 1
				}
			},
			"gradientStepList_TreeWood_43": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.0967741935483871,
					"number_Lightness_2": 0.10782380013149244,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.3668208856576338,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.24194608809993426,
					"number_Lightness_2": 0.565102445472571,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Treewood2_44": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.14990138067061143,
					"number_Lightness_2": 0.27087442472057854,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.1935483870967742,
					"number_Lightness_2": 0.6916502301117686,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5601577909270217
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.7096774193548387,
					"number_Saturation_1": 0.06451612903225806,
					"number_Lightness_2": 0.9354838709677419,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Leaf_45": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.3548387096774194,
					"number_Saturation_1": 0,
					"number_Lightness_2": 0,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.3870967741935484,
					"number_Saturation_1": 0.06451612903225806,
					"number_Lightness_2": 0.06451612903225806,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.5470085470085471
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.16129032258064516,
					"number_Lightness_2": 0.12903225806451613,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Leaf2_46": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.41935483870967744,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.03225806451612903,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.45161290322580644,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.3870967741935484,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.715318869165023
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.4838709677419355,
					"number_Saturation_1": 0.45161290322580644,
					"number_Lightness_2": 0.6774193548387096,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Snow_47": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.17911434236615995,
					"number_Saturation_1": 0.19497686715135493,
					"number_Lightness_2": 0.03225806451612903,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.11037673496364839,
					"number_Saturation_1": 0.13152676801057503,
					"number_Lightness_2": 0.8321216126900198,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.715318869165023
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.21612690019828157,
					"number_Saturation_1": 0.06278916060806344,
					"number_Lightness_2": 1,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			},
			"gradientStepList_Snow2_48": {
				"gradientStep_Step0_0": {
					"number_Hue_0": 0.16853932584269662,
					"number_Saturation_1": 0.2108393919365499,
					"number_Lightness_2": 0.29015201586252476,
					"number_Power_3": 0.1472715318869165,
					"number_Position_4": 0
				},
				"gradientStep_Step1_1": {
					"number_Hue_0": 0.20819563780568406,
					"number_Saturation_1": 0.16325181758096496,
					"number_Lightness_2": 0.6972901520158625,
					"number_Power_3": 0.14990138067061143,
					"number_Position_4": 0.715318869165023
				},
				"gradientStep_Step2_2": {
					"number_Hue_0": 0.19762062128222074,
					"number_Saturation_1": 0,
					"number_Lightness_2": 1,
					"number_Power_3": 0.09467455621301775,
					"number_Position_4": 1
				}
			}
		},
		"untypedList_Settings_1": {
			"bool_Down Samp_0": 1
		}
	}
}